﻿{
    "suicune":{name:"suicune",role:{setup:true,tank:true},deftype:{physical:true}},
    "magcargo":{name:"magcargo",statspread:{spaEV:252,spe:252}}
}