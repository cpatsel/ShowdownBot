﻿{
    "suicune":{name:"suicune",role:{setup:true,tank:true},deftype:{physical:true}},
    "magcargo":{name:"magcargo",item:"airballoon",personal:true,role:{lead:true},statspread:{spaEV:252,spe:252},certainAbility:"flamebody"}
}